package com.netand.chatsystem.chat.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class GroupChatCreateResponseDTO {

    private Long chatRoomId;
}
