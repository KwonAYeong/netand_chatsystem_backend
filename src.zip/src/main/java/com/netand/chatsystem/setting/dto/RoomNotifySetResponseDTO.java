package com.netand.chatsystem.setting.dto;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class RoomNotifySetResponseDTO {
    private String alertType;
}
