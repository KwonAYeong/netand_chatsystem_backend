package com.netand.chatsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
